/* Market Briefing: frontend vanilla, nessuna chiave API nel browser. */
'use strict';
const PREVIEW = window.MARKET_PREVIEW === true;
const CONTENT = document.getElementById('content');
const NOTICE = document.getElementById('notice');
const REFRESH = document.getElementById('refresh');
const INSTALL = document.getElementById('install');
const SECTORS = {
  oro: {name:'Oro', color:'#f6cc70', bg:'#443921', icon:'<path d="M4 10l3-5h10l3 5 2 9H2zM4 10h16"/>'},
  chip: {name:'Semiconduttori', color:'#89c6ff', bg:'#243d5b', icon:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v4m6-4v4m-6 12v4m6-4v4M2 9h4m-4 6h4m12-6h4m-4 6h4"/>'},
  bitcoin: {name:'Bitcoin', color:'#ffae65', bg:'#493322', icon:'<circle cx="12" cy="12" r="10"/><path d="M9 6v12m3-13v2m3-2v2m-3 10v2m3-2v2M7 7h7a2.5 2.5 0 0 1 0 5H9m0 0h6a2.5 2.5 0 0 1 0 5H7"/>'},
  petrolio: {name:'Petrolio', color:'#8dd9c4', bg:'#25413d', icon:'<path d="M12 2S5 10 5 15a7 7 0 0 0 14 0c0-5-7-13-7-13zM8 15c0 2 1 3 3 4"/>'},
  ai: {name:'Intelligenza artificiale', color:'#c5b0ff', bg:'#3b3057', icon:'<path d="M12 3l3 6 6 3-6 3-3 6-3-6-6-3 6-3zM20 2v4m-2-2h4M3 18v4m-2-2h4"/>'}
};
const validNumber = n => typeof n === 'number' && Number.isFinite(n);
const validSentiment = n => validNumber(n) && n >= -1 && n <= 1;
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = (n, digits=2) => validNumber(n) ? n.toLocaleString('it-IT',{minimumFractionDigits:digits,maximumFractionDigits:digits}) : '—';
const signed = (n, suffix='') => validNumber(n) ? `${n>0?'+':''}${fmt(n)}${suffix}` : 'N/D';
const tone = n => !validNumber(n) || n === 0 ? 'neutral' : n > 0 ? 'positive' : 'negative';
const sentimentLabel = n => !validSentiment(n) ? 'Non disponibile' : n > .1 ? 'Positivo' : n < -.1 ? 'Negativo' : 'Neutro';
const scoreTone = n => !validSentiment(n) || Math.abs(n)<=.1 ? 'neutral' : tone(n);
function dateTime(value){const d=new Date(value || '');return Number.isNaN(d.getTime())?'Data non disponibile':d.toLocaleString('it-IT',{dateStyle:'short',timeStyle:'short'});}
function dayLabel(value){const d=new Date(`${value}T00:00:00Z`);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString('it-IT',{day:'2-digit',month:'2-digit',timeZone:'UTC'});}
function unit(s){return esc(s.unit || 'USD');}
function sectorIcon(s){const m=SECTORS[s];return `<span class="sector-icon" style="--sector-color:${m.color};--sector-bg:${m.bg}" aria-hidden="true"><svg viewBox="0 0 24 24">${m.icon}</svg></span>`;}
function quoteStatus(s){
  if(s.data_status==='disabled')return 'Prezzi non disponibili';
  if(!validNumber(s.price))return 'Prezzo non disponibile';
  if(s.data_status==='cached_on_error')return 'Ultimo prezzo in cache';
  if(s.quote_stale)return 'Ultimo prezzo disponibile';
  return 'Ultima chiusura';
}
function sentimentTrack(n){const score=validSentiment(n)?n:null;return `<div class="sentiment-track" role="img" aria-label="Sentiment ${esc(score===null?'non disponibile':signed(score))} su scala da meno uno a più uno">${score===null?'':score===0?'<span class="sentiment-dot"></span>':`<span class="sentiment-fill ${tone(score)}" style="left:${Math.min(50,50+score*50)}%;width:${Math.abs(score)*50}%"></span>`}</div>`;}
function priceMarkup(s){return `<span class="price">${fmt(s.price)}${validNumber(s.price)?`<span class="unit">${unit(s)}</span>`:''}</span>`;}
function changeMarkup(s){return `<span class="change ${tone(s.change_24h_pct)}" title="Variazione fra le due ultime chiusure disponibili">${signed(s.change_24h_pct,'%')}</span>`;}
function counts(s){return `${Number.isInteger(s.analyzed_count)?s.analyzed_count:0}/${Number.isInteger(s.news_count)?s.news_count:0} notizie analizzate`;}
function showNotice(messages,kind=''){NOTICE.textContent=messages.join(' · ');NOTICE.className=`notice ${kind}`;NOTICE.hidden=messages.length===0;}
let activeRequest=null, requestSerial=0, currentRoute='', currentDays=30, currentData=null, deferredInstall=null, stockFilter='all';
let watchlist=new Set();try{const stored=JSON.parse(localStorage.getItem('market-watchlist-v1')||'[]');if(Array.isArray(stored))watchlist=new Set(stored.filter(x=>typeof x==='string'));}catch(_error){}
function route(){const hash=location.hash.slice(1);if(hash==='stocks')return 'stocks';const match=/^sector\/(oro|chip|bitcoin|petrolio|ai)$/.exec(hash);return match?match[1]:'';}
function navigate(name){location.hash=name==='stocks'?'stocks':name?`sector/${name}`:'home';}
function storageKey(path){return `market-briefing-v2:${path}`;}
function remember(path,data){try{localStorage.setItem(storageKey(path),JSON.stringify({saved_at:new Date().toISOString(),data}));}catch(_error){/* Storage può essere disabilitato. */}}
function restore(path){try{const item=JSON.parse(localStorage.getItem(storageKey(path)));return item&&item.data&&item.saved_at?item:null;}catch(_error){return null;}}
function safeUrl(raw){try{const u=new URL(raw);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:null;}catch(_error){return null;}}
async function load({keep=false}={}){
  const name=route();if(name!==currentRoute){currentDays=30;currentRoute=name;keep=false;}
  const path=name==='stocks'?'/stocks':name?`/sector/${name}?days=${currentDays}`:'/briefing';
  document.getElementById('tab-home').setAttribute('aria-current',name==='stocks'?'false':'page');document.getElementById('tab-stocks').setAttribute('aria-current',name==='stocks'?'page':'false');
  const serial=++requestSerial;if(activeRequest)activeRequest.abort();const controller=new AbortController();activeRequest=controller;
  REFRESH.disabled=true;CONTENT.setAttribute('aria-busy','true');
  if(!keep)CONTENT.innerHTML='<div class="loading">Caricamento dei dati…</div>';
  if(!keep)showNotice([]);let timeout;
  try{
    let data;
    if(PREVIEW){data=previewData(path);}
    else if(window.MarketNative){data=MarketLocal.data(path);}
    else{timeout=setTimeout(()=>controller.abort(),name==='stocks'?55000:16000);const res=await fetch(path,{signal:controller.signal,cache:'no-store',headers:{Accept:'application/json'}});if(!res.ok)throw new Error(`HTTP ${res.status}`);data=await res.json();}
    if(serial!==requestSerial)return;
    if(!data||(!name&&!Array.isArray(data.sectors))||(name==='stocks'&&!Array.isArray(data.stocks))||(name&&name!=='stocks'&&(!Array.isArray(data.history)||data.sector!==name)))throw new Error('Formato API non valido');
    if(!PREVIEW)remember(path,data);render(data,name,false,null);
  }catch(error){if(serial!==requestSerial)return;const saved=!PREVIEW?restore(path):null;if(saved){render(saved.data,name,true,saved.saved_at);}else{currentData=null;CONTENT.innerHTML=`${name&&name!=='stocks'?backButton():''}<div class="empty">Dati non disponibili in questo momento.<br>Controlla la connessione e riprova.<br><button class="retry" id="retry">Riprova</button></div>`;showNotice(['Dati locali non disponibili'], 'error');}}
  finally{clearTimeout(timeout);if(serial===requestSerial){REFRESH.disabled=false;CONTENT.setAttribute('aria-busy','false');}}
}
function render(data,name,cached,savedAt){
  currentData=data;const messages=[];
  if(data.local_status)messages.push(data.local_status);
  if(data.demo||PREVIEW)messages.push('DEMO · Tutti i valori e le notizie sono inventati');
  if(cached)messages.push(`Offline / dati non raggiungibili: copia salvata il ${dateTime(savedAt)}. Dati non aggiornati.`);
  if(!cached&&!navigator.onLine&&!PREVIEW&&!window.MarketNative)messages.push('Connessione assente');
  showNotice(messages,cached?'error':data.demo||PREVIEW?'demo':'');
  CONTENT.innerHTML=name==='stocks'?stocksHTML(data):name?detailHTML(data,name):homeHTML(data);
  document.title=name==='stocks'?'Trading ideas | Market Briefing':name?`${SECTORS[name].name} | Market Briefing`:'Market Briefing';
}
function homeHTML(data){
  const sectors=data.sectors.filter(s=>Object.hasOwn(SECTORS,s.sector));
  const n=sectors.reduce((a,s)=>a+(s.news_count||0),0),a=sectors.reduce((a,s)=>a+(s.analyzed_count||0),0);
  return `<section class="hero"><p class="eyebrow">Panoramica di mercato</p><h1>Briefing giornaliero</h1><p class="sub">Ultime 24 ore · Calcolato ${esc(dateTime(data.generated_at))}</p></section>
  <div class="metrics"><div class="metric"><strong>${sectors.length}</strong><span>Settori monitorati</span></div><div class="metric"><strong>${esc(n)}</strong><span>Notizie rilevate</span></div><div class="metric"><strong>${esc(a)}</strong><span>Notizie analizzate</span></div></div>
  <button class="screener-entry" data-open-stocks><span><strong>Trading ideas</strong><small>Scopri azioni in evidenza e indicatori tecnici</small></span><span aria-hidden="true">›</span></button>
  <div class="section-title"><h2>I tuoi settori</h2><span>Apri per approfondire</span></div>
  <div class="sectors">${sectors.map(s=>`<button class="sector-card" data-sector="${s.sector}" aria-label="Dettaglio ${esc(SECTORS[s.sector].name)}"><span class="sector-head"><span class="sector-ident">${sectorIcon(s.sector)}<span><span class="sector-name">${esc(SECTORS[s.sector].name)}</span><span class="ticker">${esc(s.ticker)} · ${esc(s.instrument)}</span></span></span><span class="arrow" aria-hidden="true">›</span></span><span class="quote-row">${priceMarkup(s)}<span class="change-block">${changeMarkup(s)}<span class="ticker">Ultima seduta</span></span></span><span class="sentiment-row"><span class="muted">Sentiment 24h · ${sentimentLabel(s.sentiment)}</span><strong class="${scoreTone(s.sentiment)}">${signed(validSentiment(s.sentiment)?s.sentiment:null)}</strong></span>${sentimentTrack(s.sentiment)}<span class="coverage"><span>${counts(s)}</span><span class="${s.quote_stale||s.data_status==='cached_on_error'?'status-stale':''}">${esc(quoteStatus(s))}</span></span>${s.price_at?`<span class="ticker">Prezzo: ${esc(s.price_at)}</span>`:''}</button>`).join('')}</div>
  <div class="guide"><strong>Come leggere i dati</strong><br>Sentiment da −1 (negativo) a +1 (positivo), calcolato sulle notizie analizzate. N/D significa dato non disponibile. I prezzi sono in USD, possono essere ritardati e rappresentano gli strumenti indicati, non necessariamente l’intero settore. Fonte prezzi: Alpha Vantage, uso personale. GLD e USO sono strumenti proxy, non il prezzo spot o il future. Le notizie istituzionali possono essere poco frequenti. Il conteggio può includere una notizia in più settori.</div>`;
}
function backButton(){return '<button class="back" id="back"><svg viewBox="0 0 24 24"><path d="M19 12H5m7-7-7 7 7 7"/></svg> Tutti i settori</button>';}
function lineChart(history,key){
  const isScore=key==='sentiment';const ok=isScore?validSentiment:validNumber;const values=history.filter(p=>ok(p[key])).map(p=>p[key]);
  const title=isScore?'Sentiment giornaliero':'Prezzo storico';const hint=isScore?'Media giornaliera · giorni UTC · scala da −1 a +1':'Chiusure disponibili · date del mercato · USD';
  if(!values.length)return `<div class="chart"><h3>${title}</h3><p class="sub">${hint}</p><div class="chart-empty">Nessun dato disponibile nel periodo.</div></div>`;
  const rawMin=Math.min(...values),rawMax=Math.max(...values);const pad=Math.max((rawMax-rawMin)*.10,Math.abs(rawMax)*.002,.01);
  const min=isScore?-1:rawMin-pad,max=isScore?1:rawMax+pad;
  const w=360,h=166,left=64,right=348,top=13,bottom=133;
  const x=i=>history.length===1?(left+right)/2:left+(right-left)*i/(history.length-1);const y=v=>bottom-(v-min)/(max-min)*(bottom-top);
  const ticks=[max,(max+min)/2,min];const grid=ticks.map(v=>`<line class="gridline" x1="${left}" x2="${right}" y1="${y(v)}" y2="${y(v)}"/><text class="axis" x="${left-6}" y="${y(v)+3}" text-anchor="end">${esc(fmt(v,isScore?1:2))}</text>`).join('');
  let d='',open=false;const dots=[];
  history.forEach((p,i)=>{if(!ok(p[key])){open=false;return;}d+=`${open?'L':'M'}${x(i).toFixed(2)},${y(p[key]).toFixed(2)} `;open=true;dots.push(`<circle cx="${x(i)}" cy="${y(p[key])}" r="${history.length>45?1.6:2.6}" fill="${isScore?'#c5b0ff':'#82d4f5'}"><title>${esc(p.date)}: ${esc(fmt(p[key]))}${p.provisional?' (provvisorio)':''}</title></circle>`);});
  const indices=[...new Set([0,Math.floor((history.length-1)/2),history.length-1])];const dates=indices.map(i=>`<text class="axis" x="${x(i)}" y="154" text-anchor="${i===0?'start':i===history.length-1?'end':'middle'}">${esc(dayLabel(history[i].date))}</text>`).join('');
  return `<div class="chart"><h3>${title}</h3><p class="sub">${hint}</p><svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${title}, ${values.length} valori disponibili su ${history.length} giorni. Le lacune restano vuote.">${grid}<path class="series" d="${d}" stroke="${isScore?'#c5b0ff':'#82d4f5'}"/>${dots.join('')}${dates}</svg></div>`;
}
function newsHTML(n){const link=safeUrl(n.link);const score=validSentiment(n.sentiment)?n.sentiment:null;return `<article class="news-item"><div class="news-meta"><span>${esc(n.source||'Fonte non indicata')} · ${esc(dateTime(n.published_at))}${n.date_basis==='fetched_at'?' (acquisizione)':''}</span><strong class="${scoreTone(score)}">${signed(score)}</strong></div><h3>${esc(n.title||'Titolo non disponibile')}</h3><p>${esc(n.summary||'Sintesi non disponibile.')}</p>${link?`<a href="${esc(link)}" target="_blank" rel="noopener noreferrer">Apri fonte originale ↗</a>`:''}</article>`;}
function detailHTML(s,name){
  const rows=s.history||[],news=s.news||[];const pricesStatus=s.price_history_status==='cached_on_error'?' · copia in cache':s.price_history_status==='disabled'?' · disabilitati':'';
  return `${backButton()}<section class="detail-hero">${sectorIcon(name)}<div><p class="eyebrow">Dettaglio settore</p><h1>${esc(SECTORS[name].name)}</h1><p class="sub">${esc(s.ticker)} · ${esc(s.instrument)}</p></div></section>
  <div class="detail-summary"><div class="summary-tile"><span>Ultima quotazione</span><strong>${priceMarkup(s)}</strong><div class="sub">${esc(quoteStatus(s))}${s.price_at?` · ${esc(s.price_at)}`:''}</div><div class="sub">Seduta: ${changeMarkup(s)}</div>${s.reference_at&&validNumber(s.change_24h_pct)?`<div class="sub">Rif. ${esc(s.reference_at)}</div>`:''}</div><div class="summary-tile"><span>Sentiment ultime 24 ore</span><strong class="${scoreTone(s.sentiment)}">${signed(validSentiment(s.sentiment)?s.sentiment:null)}</strong><div class="sub">${sentimentLabel(s.sentiment)}</div>${sentimentTrack(s.sentiment)}<div class="sub">${counts(s)}</div></div></div>
  <div class="section-title"><h2>Andamento</h2><div class="periods" role="group" aria-label="Periodo storico">${[7,30,90].map(d=>`<button data-days="${d}" aria-pressed="${d===currentDays}">${d} g</button>`).join('')}</div></div>
  <p class="sub" style="margin-bottom:12px">${esc(s.days)} giorni · oggi provvisorio · dati mancanti non interpolati${pricesStatus}</p><div class="charts">${lineChart(rows,'sentiment')}${lineChart(rows,'price')}</div>
  <details class="data-table"><summary>Visualizza tabella dei dati</summary><div class="table-scroll"><table><thead><tr><th scope="col">Data</th><th scope="col">Sentiment</th><th scope="col">Notizie</th><th scope="col">Prezzo USD</th></tr></thead><tbody>${[...rows].reverse().map(p=>`<tr><td>${esc(p.date)}${p.provisional?' *':''}</td><td>${signed(validSentiment(p.sentiment)?p.sentiment:null)}</td><td>${esc(p.analyzed_count)}/${esc(p.news_count)}</td><td>${fmt(p.price)}</td></tr>`).join('')}</tbody></table></div><p>* Dato di oggi provvisorio.</p></details>
  <div class="section-title" style="margin-top:22px"><h2>Notizie e contesto</h2><span>${news.length} di ${esc(s.news_total??news.length)}</span></div><p class="sub" style="margin-bottom:12px">Dalle più recenti · fonti originali quando disponibili</p><div class="news-list">${news.length?news.map(newsHTML).join(''):'<div class="empty">Nessuna notizia disponibile nel periodo selezionato.</div>'}</div><div class="guide"><strong>Nota metodologica</strong><br>I punteggi sono calcolati localmente da parole chiave dei titoli RSS inglesi, senza Claude. I titoli non classificabili restano N/D. Il tono non è una previsione né una stima dell’impatto sui prezzi. La quotazione può essere ritardata; la variazione confronta le due ultime chiusure, non esattamente 24 ore.</div>`;
}
function stockStatus(s){if(s.status==='disabled')return 'Prezzi non disponibili';if(s.status==='cached_on_error')return 'Copia in cache';if(!validNumber(s.price))return 'Dati non disponibili';if(s.stale)return 'Dati non recenti';if(!s.eligible)return 'Titolo non valutabile';return 'Seduta conclusa';}
function stockCard(s){
  const starred=watchlist.has(s.ticker), obs=s.observations||[], risks=s.risks||[];
  const stat=(label,value,extra='')=>`<div><small>${label}</small><strong class="${extra}">${value}</strong></div>`;
  return `<article class="stock-card"><div class="stock-heading"><div class="stock-symbol" aria-hidden="true">${esc(s.ticker.split('.')[0].slice(0,4))}</div><div class="stock-ident"><strong>${esc(s.name)}</strong><small>${esc(s.ticker)} · ${esc(s.theme)} · ${esc(s.region)}</small></div><button class="star" data-watch="${esc(s.ticker)}" aria-pressed="${starred}" aria-label="${starred?'Rimuovi':'Aggiungi'} ${esc(s.name)} ${starred?'dalla':'alla'} watchlist">${starred?'★':'☆'}</button></div>
  <div class="quote-row"><span class="price">${fmt(s.price)} <span class="unit">${esc(s.currency)}</span></span><span class="change-block"><span class="change ${tone(s.return_1d)}">${signed(s.return_1d,'%')}</span><span class="ticker">1 seduta</span></span></div>
  <p class="sub stock-date">${esc(stockStatus(s))}${s.date?' · '+esc(s.date):''}</p>
  <div class="stock-metrics">${stat('5 sedute',signed(s.return_5d,'%'),tone(s.return_5d))}${stat('20 sedute',signed(s.return_20d,'%'),tone(s.return_20d))}${stat('RSI 14',fmt(s.rsi14,1))}${stat('Volume / media',validNumber(s.relative_volume)?fmt(s.relative_volume,1)+'×':'N/D')}</div>
  <div class="stock-observation"><small>PERCHÉ OSSERVARLO</small><p>${obs.length?esc(obs[0]):s.eligible?'Nessuna soglia di attenzione raggiunta.':'Non valutato: dati mancanti, insufficienti o non recenti.'}</p></div>
  <details class="stock-detail"><summary>Indicatori, motivazioni e rischi</summary><div class="stock-metrics">${stat('Distanza MM20',signed(s.distance_ma20,'%'),tone(s.distance_ma20))}${stat('Distanza MM50',signed(s.distance_ma50,'%'),tone(s.distance_ma50))}${stat('Volatilità giorn.',validNumber(s.volatility_daily_20d)?fmt(s.volatility_daily_20d)+'%':'N/D')}${stat('Sedute disponibili',esc(s.sessions??'N/D'))}</div>${obs.length>1?`<p class="sub"><strong>Altre osservazioni</strong></p><ul>${obs.slice(1).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}<p class="sub"><strong>Rischi e verifiche</strong></p><ul>${risks.map(x=>`<li>${esc(x)}</li>`).join('')}<li>Verifica risultati trimestrali, notizie societarie, liquidità e commissioni. Per i titoli USD considera il rischio di cambio.</li></ul></details></article>`;
}
function stocksHTML(data){
  const stocks=data.stocks||[], visible=stocks.filter(s=>stockFilter==='all'||(stockFilter==='highlighted'&&s.highlighted)||(stockFilter==='watchlist'&&watchlist.has(s.ticker))||(stockFilter==='USA'&&s.region==='USA')||(stockFilter==='Europa'&&s.region==='Europa')||(stockFilter==='Asia'&&s.region==='Asia'));
  const available=stocks.filter(s=>s.eligible).length, highlighted=stocks.filter(s=>s.highlighted).length;
  return `<section class="hero"><p class="eyebrow">Screener azionario · Swing trading</p><h1>Trading ideas</h1><p class="sub">Titoli da approfondire · Elaborazione ${esc(dateTime(data.generated_at))}</p></section>
  <div class="metrics"><div class="metric"><strong>${stocks.length}</strong><span>Titoli monitorati</span></div><div class="metric"><strong>${available}</strong><span>Valutabili</span></div><div class="metric"><strong>${highlighted}</strong><span>In evidenza</span></div></div>
  <div class="stock-intro"><strong>Opportunità di studio, non segnali operativi.</strong><p>Trend, RSI e volumi individuano titoli da approfondire. Non sono previsioni di rendimento.</p></div>
  <div class="stock-filters" aria-label="Filtra azioni">${[['highlighted','In evidenza'],['all','Tutte'],['USA','USA'],['Europa','Europa (società)'],['Asia','Asia (società)'],['watchlist','Watchlist']].map(([k,label])=>`<button data-stock-filter="${k}" aria-pressed="${stockFilter===k}">${label}${k==='watchlist'?' ('+watchlist.size+')':''}</button>`).join('')}</div><p class="sub stock-count">${visible.length} titoli · Chiusure precedenti al giorno corrente (no intraday) · tutti i titoli in USD</p>
  <div class="sectors stock-grid">${visible.length?visible.map(stockCard).join(''):`<div class="empty">${stockFilter==='watchlist'?'Nessun titolo salvato. Tocca la stella su un titolo.':available===0?'Nessun titolo valutabile. Inserisci la chiave gratuita dalle impostazioni; seleziona Tutte per vedere lo stato.':'Nessun titolo corrisponde al filtro.'}</div>`}</div>
  <div class="guide"><strong>Metodo e limiti</strong><br>Variazioni su chiusure NON rettificate per split e dividendi, MM20/MM50: media mobile semplice; RSI 14 di Wilder; volume rispetto alle 20 sedute precedenti; volatilità: deviazione standard dei rendimenti giornalieri delle ultime 20 sedute. L'ultima seduta locale corrente è sempre esclusa per prudenza. Le soglie non sono una strategia validata e non prevedono i movimenti futuri. Non vengono analizzate notizie specifiche, bilanci o date degli utili delle società. Watchlist salvata sul dispositivo.</div>`;
}

CONTENT.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;if(button.hasAttribute('data-open-stocks'))navigate('stocks');else if(button.dataset.stockFilter&&currentRoute==='stocks'&&currentData){stockFilter=button.dataset.stockFilter;CONTENT.innerHTML=stocksHTML(currentData);}else if(button.dataset.watch&&currentRoute==='stocks'&&currentData){const ticker=button.dataset.watch;if(watchlist.has(ticker))watchlist.delete(ticker);else watchlist.add(ticker);try{localStorage.setItem('market-watchlist-v1',JSON.stringify([...watchlist]));}catch(_error){}CONTENT.innerHTML=stocksHTML(currentData);}else if(button.dataset.sector&&Object.hasOwn(SECTORS,button.dataset.sector))navigate(button.dataset.sector);else if(button.id==='back')navigate('');else if(button.dataset.days&&[7,30,90].includes(Number(button.dataset.days))){currentDays=Number(button.dataset.days);load({keep:true});}else if(button.id==='retry')load();});
document.getElementById('tab-home').addEventListener('click',()=>navigate(''));
document.getElementById('tab-stocks').addEventListener('click',()=>navigate('stocks'));
window.addEventListener('hashchange',()=>{window.scrollTo(0,0);load();});
REFRESH.addEventListener('click',()=>{load({keep:true});if(window.MarketNative)MarketLocal.refresh();});
document.getElementById('settings')?.addEventListener('click',()=>MarketLocal.configure());
document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(a&&window.MarketNative){e.preventDefault();const u=safeUrl(a.href);if(u&&u.startsWith('https:'))MarketNative.openExternal(u);}});
window.addEventListener('online',()=>{if(window.MarketNative)MarketLocal.refresh();});
window.addEventListener('online',()=>load({keep:true}));
window.addEventListener('offline',()=>{if(!PREVIEW)load({keep:true});});
window.addEventListener('beforeinstallprompt',e=>{if(PREVIEW)return;e.preventDefault();deferredInstall=e;INSTALL.hidden=false;});
INSTALL.addEventListener('click',async()=>{if(!deferredInstall)return;const prompt=deferredInstall;deferredInstall=null;INSTALL.hidden=true;try{await prompt.prompt();}catch(_error){/* L'installazione puo essere annullata. */}});
window.addEventListener('appinstalled',()=>{INSTALL.hidden=true;deferredInstall=null;});
if(!window.MarketNative&&!PREVIEW&&'serviceWorker' in navigator&&window.isSecureContext){navigator.serviceWorker.register('/sw.js').catch(e=>console.warn('Service worker:',e.name));}
load();
if(window.MarketNative){MarketLocal.refresh();setInterval(()=>{if(!document.hidden)MarketLocal.refresh();},3600000);}

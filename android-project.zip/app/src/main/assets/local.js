/* Adattatore locale: rete tramite bridge Android a lista chiusa; dati privati nel WebView. */
'use strict';
const MarketLocal=(()=>{
 const STORAGE='market-local-v1',DAY=86400000;let db={news:[],prices:{},attempts:{},lastRSS:0,errors:[]};
 try{const d=JSON.parse(localStorage.getItem(STORAGE)||'null');if(d&&Array.isArray(d.news)&&d.prices&&d.attempts)db=d;}catch(_){}
 const bridge=window.MarketNative;const requests=new Map();let serial=0,busy=false,notice='';
 function save(){try{localStorage.setItem(STORAGE,JSON.stringify(db));}catch(_){notice='Memoria locale non disponibile';}}
 window.marketNativeResult=(id,ok,body)=>{const r=requests.get(id);if(!r)return;requests.delete(id);clearTimeout(r.timer);ok?r.resolve(body):r.reject(Error(body));};
 function request(type,name){return new Promise((resolve,reject)=>{if(!bridge){reject(Error('App Android non disponibile'));return;}const id=String(++serial);const timer=setTimeout(()=>{requests.delete(id);reject(Error('Timeout'));},35000);requests.set(id,{resolve,reject,timer});try{bridge.request(id,type,name);}catch(e){clearTimeout(timer);requests.delete(id);reject(e);}});}
 function status(){return [notice,bridge?.hasKey()?'':'Prezzi: inserisci la chiave gratuita nelle impostazioni',...db.errors.slice(-4)].filter(Boolean).join(' · ');}
 function display(){if(typeof load==='function')load({keep:true});}
 async function refresh(){
  if(busy||!bridge)return;busy=true;db.errors=[];notice='Aggiornamento in corso';display();
  try{
   const now=Date.now(),today=new Date(now).toISOString().slice(0,10);
   if(now-db.lastRSS>=3600000){db.lastRSS=now;save();for(const id of Object.keys(Market.feeds)){try{const text=await request('rss',id);db.news=Market.mergeNews(db.news,Market.parseFeed(text,id));}catch(e){db.errors.push('RSS '+id+': '+e.message);}save();}}
   if(bridge.hasKey()){
    const names=[...Object.values(Market.sectors).map(s=>s[0]),...Market.stocks.map(s=>s[0])];
    const todo=names.filter(s=>db.attempts[s]!==today);
    let i=0;for(const s of todo){notice=`Quotazioni ${++i}/${todo.length} · ${s}`;display();db.attempts[s]=today;save();
     try{db.prices[s]=Market.parsePrices(await request('price',s),s);}
     catch(e){db.errors.push(s+': '+e.message);if(/limite richieste|chiave non valida|HTTP 429/.test(e.message)){db.errors.push('Aggiornamento prezzi interrotto: riprova domani');break;}}
     save();
    }
   }
  }finally{busy=false;notice='';save();display();}
 }
 function data(path){return {...Market.payload(path,db),local_status:status()};}
 window.marketKeyChanged=()=>{display();refresh();};window.marketResume=()=>refresh();
 return {data,refresh,configure:()=>bridge?.configure(),status};
})();

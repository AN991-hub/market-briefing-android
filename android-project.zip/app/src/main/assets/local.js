/* Rete tramite bridge Android a lista chiusa; dati privati nel WebView. */
'use strict';
const MarketLocal=(()=>{
 const STORAGE='market-local-v1',DAY=86400000,PRICE_DELAY=13000;
 let db={news:[],prices:{},attempts:{},lastRSS:0,errors:[]};
 try{const d=JSON.parse(localStorage.getItem(STORAGE)||'null');if(d&&Array.isArray(d.news)&&d.prices&&d.attempts)db=d;}catch(_){}
 db.rssStatus=db.rssStatus||{};db.priceErrors=db.priceErrors||[];db.blockedUntil=db.blockedUntil||0;db.quotaDay=db.quotaDay||'';
 const bridge=window.MarketNative,requests=new Map();let serial=0,busy=false,notice='';
 const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 function save(){try{localStorage.setItem(STORAGE,JSON.stringify(db));}catch(_){notice='Memoria locale non disponibile';}}
 window.marketNativeResult=(id,ok,body)=>{const r=requests.get(id);if(!r)return;requests.delete(id);clearTimeout(r.timer);ok?r.resolve(body):r.reject(Error(body));};
 function request(type,name){return new Promise((resolve,reject)=>{if(!bridge){reject(Error('App Android non disponibile'));return;}const id=String(++serial);const timer=setTimeout(()=>{requests.delete(id);reject(Error('Timeout'));},35000);requests.set(id,{resolve,reject,timer});try{bridge.request(id,type,name);}catch(e){clearTimeout(timer);requests.delete(id);reject(e);}});}
 function status(){
  const today=new Date().toISOString().slice(0,10),rss=Object.entries(db.rssStatus);
  const newsStatus=rss.length?'Notizie: '+rss.filter(([,r])=>r.ok).length+'/'+Object.keys(Market.feeds).length+' feed letti'+(rss.some(([,r])=>!r.ok)?' ('+rss.filter(([,r])=>!r.ok).map(([id,r])=>id.toUpperCase()+': '+r.error).join(', ')+')':''):'';
  const priceStatus=db.quotaDay===today?'Quota prezzi esaurita: riprova il giorno successivo':Date.now()<db.blockedUntil?'Limite temporaneo: riprova tra almeno un minuto':'';
  return [notice,bridge?.hasKey()?'':'Prezzi: inserisci la chiave gratuita nelle impostazioni',priceStatus,newsStatus,...db.priceErrors.slice(-3)].filter(Boolean).join(' · ');
 }
 function display(){if(typeof load==='function')load({keep:true});}
 async function refresh(){
  if(busy||!bridge)return;busy=true;notice='Aggiornamento in corso';display();
  try{
   const now=Date.now(),today=new Date(now).toISOString().slice(0,10);
   if(now-db.lastRSS>=3600000||!Object.keys(db.rssStatus).length){
    db.lastRSS=now;save();
    for(const id of Object.keys(Market.feeds)){
     try{const text=await request('rss',id),rows=Market.parseFeed(text,id);db.news=Market.mergeNews(db.news,rows);db.rssStatus[id]={ok:true,count:rows.length};}
     catch(e){db.rssStatus[id]={ok:false,error:e.message};}save();
    }
   }
   if(bridge.hasKey()&&db.quotaDay!==today&&now>=db.blockedUntil){
    db.priceErrors=[];
    const names=[...Object.values(Market.sectors).map(s=>s[0]),...Market.stocks.map(s=>s[0])];
    const todo=names.filter(s=>db.attempts[s]!==today);
    let i=0;
    for(const s of todo){
     if(new Date().toISOString().slice(0,10)!==today)break;
     // Conservative spacing even with the free daily allowance; no burst calls.
     if(i>0)await pause(PRICE_DELAY);
     notice=`Quotazioni ${++i}/${todo.length} · ${s} · tieni aperta l'app`;display();
     try{db.prices[s]=Market.parsePrices(await request('price',s),s);db.attempts[s]=today;}
     catch(e){
      const msg=String(e.message);db.priceErrors.push(s+': '+msg);
      if(/quota giornaliera|limite locale giornaliero/i.test(msg)){db.quotaDay=today;break;}
      if(/limite temporaneo|HTTP 429/i.test(msg)){db.blockedUntil=Date.now()+65000;break;}
      if(/chiave non valida/i.test(msg))break;
      // Only failed temporary requests can be retried, within the native quota.
      db.attempts[s]=today;
     }
     save();display();
    }
   }
  }finally{busy=false;notice='';save();display();}
 }
 function data(path){return {...Market.payload(path,db),local_status:status()};}
 window.marketKeyChanged=()=>{display();refresh();};window.marketResume=()=>refresh();
 return {data,refresh,configure:()=>bridge?.configure(),status};
})();

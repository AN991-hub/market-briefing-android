/* Calcoli locali, senza API a pagamento. Funzioni pure, testabili con Node. */
'use strict';
const Market = (()=>{
 const sectors={oro:['GLD','Fondo aurifero USA (proxy oro)'],chip:['SMH','ETF semiconduttori USA'],bitcoin:['BTC','Bitcoin / USD'],petrolio:['USO','Fondo future WTI (proxy petrolio)'],ai:['AIQ','ETF AI e tecnologia USA']};
 const stocks=[['NVDA','NVIDIA','Chip / AI'],['AMD','AMD','Chip / AI'],['AVGO','Broadcom','Chip'],['MSFT','Microsoft','AI / Cloud'],['GOOGL','Alphabet','AI / Cloud'],['PLTR','Palantir','AI / Software'],['AAPL','Apple','Tecnologia'],['XOM','Exxon Mobil','Petrolio'],['NEM','Newmont','Oro'],['COIN','Coinbase','Cripto'],['E','Eni (ADR USA)','Energia','Europa'],['STM','STMicroelectronics (USA)','Chip','Europa'],['ASML','ASML (USA)','Chip','Europa'],['SAP','SAP (ADR USA)','Software','Europa'],['TSM','TSMC (ADR USA)','Chip','Asia'],['JPM','JPMorgan','Banche']];
 const feeds={usgs:{source:'USGS',host:'usgs.gov',rules:{oro:/\b(gold|precious metals)\b/i}},eia:{source:'EIA',host:'eia.gov',rules:{petrolio:/\b(oil|crude|petroleum|gasoline|diesel|refiner\w*|brent|wti|opec)\b/i}},sec:{source:'SEC',host:'sec.gov',rules:{bitcoin:/\b(bitcoin|btc|crypto\w*|digital assets?)\b/i,chip:/\b(semiconductors?|microchips?|nvidia|tsmc|asml)\b/i,ai:/\b(artificial intelligence|machine learning|AI)\b/i}},nist:{source:'NIST',host:'nist.gov',rules:{chip:/\b(semiconductors?|microchips?|chips?|microelectronics)\b/i,ai:/\b(artificial intelligence|machine learning|AI|large language models?)\b/i}}};
 const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
 const numeric=x=>typeof x==='number'&&Number.isFinite(x);
 const number=x=>x!==null&&x!==undefined&&String(x).trim()!==''&&Number.isFinite(Number(x))?Number(x):null;
 const day=t=>new Date(t).toISOString().slice(0,10);
 const marketDay=(symbol,now)=>{if(symbol==='BTC')return day(now);const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).map(p=>[p.type,p.value]));return `${parts.year}-${parts.month}-${parts.day}`;};
 function parsePrices(body,symbol,now=new Date()){
  const j=typeof body==='string'?JSON.parse(body):body;
  const series=j['Time Series (Daily)']||j['Time Series (Digital Currency Daily)'];
  if(!series||typeof series!=='object'){const info=String(j.Information||j.Note||j['Error Message']||'');if(/rate limit|requests per day|requests per minute|frequency|call frequency/i.test(info))throw Error('API: limite richieste');if(/api key.*invalid|invalid.*api key|claim your free api key/i.test(info))throw Error('API: chiave non valida');throw Error('API: simbolo o funzione non disponibile');}
  const cutoff=marketDay(symbol,now);
  const rows=Object.entries(series).filter(([d])=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&d<cutoff).map(([date,v])=>({date,price:number(v['4. close']??v['4a. close (USD)']??v['4b. close (USD)']),volume:number(v['5. volume'])})).filter(r=>numeric(r.price)&&r.price>0).sort((a,b)=>a.date.localeCompare(b.date)).slice(-100);
  if(!rows.length)throw Error('API: nessuna chiusura valida');return rows;
 }
 function tone(title){
  // Tono lessicale inglese; non interpreta l'effetto economico su un settore.
  // Parole come "rate", "price", "rise" o "fall" da sole sono ambigue.
  const pos=(title.match(/\b(growth|record profits?|profit growth|expands?|expansion|breakthrough|approval|approved|recovery|improves?|improvement|strong demand|success(?:ful)?)\b/gi)||[]).length;
  const neg=(title.match(/\b(losses|loss|fraud|lawsuit|hack(?:ed|ing)?|breach|bankruptcy|default|recession|shortage|weak demand|decline|layoffs|disruption|failure|sanctions?)\b/gi)||[]).length;
  if(/\b(no|not|never|without|denies|denied)\b/i.test(title))return null;
  return pos+neg?Math.max(-1,Math.min(1,(pos-neg)/(pos+neg))):null;
 }
 function averageNews(rows){const a=rows.map(x=>x.sentiment).filter(numeric);return {sentiment:mean(a),news_count:rows.length,analyzed_count:a.length};}
 function parseFeed(xml,id,now=Date.now()){
  if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('XML non consentito');
  const doc=new DOMParser().parseFromString(xml,'application/xml');
  if(doc.querySelector('parsererror')||!['rss','feed','RDF'].includes(doc.documentElement.localName))throw Error('Risposta non RSS');
  const f=feeds[id],out=[];
  for(const item of Array.from(doc.getElementsByTagName('*')).filter(n=>['item','entry'].includes(n.localName)).slice(0,100)){
   const child=(...names)=>Array.from(item.children).find(n=>names.includes(n.localName));
   const title=child('title')?.textContent.trim().replace(/\s+/g,' ').slice(0,500);const stamp=Date.parse(child('pubDate','published','updated','date')?.textContent||'');
   const linkNode=child('link');let u;try{u=new URL(linkNode?.getAttribute('href')||linkNode?.textContent.trim()||'');}catch(_){continue;}
   if(!title||!Number.isFinite(stamp)||stamp>now||now-stamp>90*86400000||u.protocol!=='https:'||u.username||u.password||!(u.hostname===f.host||u.hostname.endsWith('.'+f.host)))continue;
   for(const [sector,rule] of Object.entries(f.rules))if(rule.test(title))out.push({sector,title,source:f.source,link:u.href,published_at:new Date(stamp).toISOString(),sentiment:tone(title),summary:'Titolo RSS originale (in inglese). Apri la fonte per il contesto.'});
  }return out;
 }
 function mergeNews(old,added,now=Date.now()){
  const map=new Map();for(const n of [...old,...added])if(Date.parse(n.published_at)>=now-90*86400000)map.set(n.sector+'|'+n.link,n);
  return [...map.values()].sort((a,b)=>b.published_at.localeCompare(a.published_at)).slice(0,1500);
 }
 function rsi(p){if(p.length<15)return null;let up=0,down=0;for(let i=1;i<=14;i++){let d=p[i]-p[i-1];up+=Math.max(d,0)/14;down+=Math.max(-d,0)/14;}for(let i=15;i<p.length;i++){let d=p[i]-p[i-1];up=(up*13+Math.max(d,0))/14;down=(down*13+Math.max(-d,0))/14;}return down===0?(up===0?50:100):100-100/(1+up/down);}
 const change=(x,y)=>numeric(x)&&numeric(y)&&y>0?(x/y-1)*100:null;
 function stockData(def,rows=[],now=Date.now()){
  const [ticker,name,theme,region='USA']=def,p=rows.map(x=>x.price),last=rows.at(-1),price=last?.price??null;
  const stale=!last||now-Date.parse(last.date+'T00:00:00Z')>5*86400000;
  const daily=p.slice(1).map((x,i)=>change(x,p[i]));const abnormal=daily.slice(-50).some(x=>Math.abs(x)>25);
  const ret=n=>change(price,p.at(-1-n));const mm=n=>p.length>=n?mean(p.slice(-n)):null;const r=rsi(p);
  const volrows=rows.slice(-21,-1).map(x=>x.volume);const vbase=volrows.length===20&&volrows.every(numeric)?mean(volrows):null;
  const relative=numeric(last?.volume)&&vbase>0?last.volume/vbase:null;
  const recent=daily.slice(-20),m=mean(recent);const volatility=recent.length===20?Math.sqrt(mean(recent.map(x=>(x-m)**2))):null;
  const eligible=!!last&&!stale&&!abnormal&&p.length>=50;
  const observations=[],risks=['Serie di prezzi non rettificata per split o dividendi; verificare eventi societari.'];
  if(eligible){if(price>mm(20)&&price>mm(50)&&ret(5)>2)observations.push('Trend positivo e chiusura sopra le medie mobili: approfondire il contesto.');if(price<mm(20)&&price<mm(50)&&ret(5)<-2)observations.push('Trend negativo e chiusura sotto le medie mobili: approfondire il contesto.');if(relative>=1.5)observations.push('Volume superiore a 1,5 volte la media delle 20 sedute precedenti.');if(r>=70||r<=30)observations.push('RSI in area estrema: non implica inversione.');}
  if(abnormal)risks.push('Movimento superiore al 25% in una seduta nelle ultime 50: possibile evento societario; escluso dallo screener.');
  if(stale)risks.push('Dati assenti o non recenti.');if(volatility>=3)risks.push('Elevata volatilità storica giornaliera.');
  return {ticker,name,theme,region,currency:'USD',status:last?'available':'missing',date:last?.date,price,stale,eligible,highlighted:eligible&&observations.length>0,return_1d:ret(1),return_5d:ret(5),return_20d:ret(20),rsi14:r,relative_volume:relative,distance_ma20:change(price,mm(20)),distance_ma50:change(price,mm(50)),volatility_daily_20d:volatility,sessions:p.length,observations,risks};
 }
 function sectorData(name,db,days=30,now=Date.now()){
  const [ticker,instrument]=sectors[name],rows=db.prices[ticker]||[],last=rows.at(-1),prev=rows.at(-2);
  const all=db.news.filter(n=>n.sector===name&&Date.parse(n.published_at)<=now),recent=all.filter(n=>Date.parse(n.published_at)>=now-86400000),today=day(now);
  const history=Array.from({length:days},(_,i)=>{const date=day(now-(days-1-i)*86400000);return {date,...averageNews(all.filter(n=>n.published_at.slice(0,10)===date)),price:rows.find(r=>r.date===date)?.price??null,provisional:date===today};});
  const news=all.filter(n=>Date.parse(n.published_at)>=now-days*86400000);
  return {sector:name,ticker:ticker==='BTC'?'BTC/USD':ticker,instrument,unit:'USD',...averageNews(recent),price:last?.price??null,price_at:last?.date,reference_at:prev?.date,change_24h_pct:change(last?.price,prev?.price),data_status:last?'available':'missing',quote_stale:!last||now-Date.parse(last.date+'T00:00:00Z')>5*86400000,price_history_status:last?'available':'missing',history,days,news:news.slice(0,100),news_total:news.length,top_news:recent.slice(0,3)};
 }
 function payload(path,db,now=Date.now()){
  const base={generated_at:new Date(now).toISOString(),local:true};
  if(path==='/briefing')return {...base,sectors:Object.keys(sectors).map(n=>sectorData(n,db,7,now))};
  if(path==='/stocks')return {...base,stocks:stocks.map(s=>stockData(s,db.prices[s[0]],now)).sort((a,b)=>Number(b.highlighted)-Number(a.highlighted))};
  const m=/^\/sector\/(oro|chip|bitcoin|petrolio|ai)\?days=(7|30|90)$/.exec(path);if(m)return {...base,...sectorData(m[1],db,+m[2],now)};throw Error('Percorso non valido');
 }
 return {sectors,stocks,feeds,mean,parsePrices,tone,averageNews,parseFeed,mergeNews,rsi,stockData,sectorData,payload};
})();
if(typeof module!=='undefined')module.exports=Market;

package it.marketbriefing.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;

/** WebView con soli asset locali; nessuna pagina remota puo usare il bridge. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final Set<String> ASSETS = Set.of("/index.html", "/styles.css", "/app.js", "/local.js", "/market.js");
    private static final Map<String,String> FEEDS = Map.of(
        "usgs", "https://www.usgs.gov/news/minerals/feed",
        "eia", "https://www.eia.gov/rss/todayinenergy.xml",
        "sec", "https://www.sec.gov/news/pressreleases.rss",
        "nist", "https://www.nist.gov/news-events/news/rss.xml");
    private static final Set<String> SYMBOLS = Set.of("GLD","SMH","BTC","USO","AIQ","NVDA","AMD","AVGO","MSFT","GOOGL","PLTR","AAPL","XOM","NEM","COIN","E","STM","ASML","SAP","TSM","JPM");
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private WebView web;
    private SharedPreferences prefs;
    private volatile boolean destroyed;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,23,33));
        getWindow().setNavigationBarColor(Color.rgb(16,23,33));
        prefs=getSharedPreferences("private_market", MODE_PRIVATE);
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(16,23,33));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false); s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        WebView.setWebContentsDebuggingEnabled(false);
        web.addJavascriptInterface(new Bridge(), "MarketNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); if (r.isForMainFrame() && local(u) && "/index.html".equals(u.getPath())) return false;
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); String p=u.getPath();
                if(local(u)&&ASSETS.contains(p)) try {
                    String mime=p.endsWith(".js")?"application/javascript":p.endsWith(".css")?"text/css":"text/html";
                    return new WebResourceResponse(mime,"UTF-8",getAssets().open(p.substring(1)));
                }catch(Exception ignored){}
                return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",Map.of(),new ByteArrayInputStream(new byte[0]));
            }
        });
        setContentView(web); web.loadUrl(HOME);
    }
    private static boolean local(Uri u){return "https".equals(u.getScheme())&&HOST.equals(u.getHost())&&u.getPort()==-1&&u.getUserInfo()==null;}
    @Override protected void onResume(){super.onResume();if(web!=null)web.evaluateJavascript("window.marketResume&&window.marketResume()",null);}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("if(location.hash&&location.hash!=='#home'){location.hash='home'}else{MarketNative.closeApp()}",null);else super.onBackPressed();}
    @Override protected void onDestroy(){destroyed=true;worker.shutdownNow();if(web!=null){web.removeJavascriptInterface("MarketNative");web.destroy();web=null;}super.onDestroy();}
    private void eval(String js){runOnUiThread(()->{if(!destroyed&&web!=null)web.evaluateJavascript(js,null);});}
    private void done(String id,boolean ok,String body){eval("window.marketNativeResult("+JSONObject.quote(id)+","+ok+","+JSONObject.quote(body)+")");}
    private String fetch(String url,boolean api) throws Exception {
        HttpsURLConnection c=(HttpsURLConnection)new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent","MarketBriefing/0.3 (personal educational reader)");
        c.setRequestProperty("Accept",api?"application/json":"application/rss+xml, application/atom+xml, application/xml, text/xml");
        try {
            int status=c.getResponseCode(); if(status!=200)throw new IllegalStateException("HTTP "+status);
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>2_000_000)throw new IllegalStateException("Risposta troppo grande");out.write(b,0,n);}
                return new String(out.toByteArray(),StandardCharsets.UTF_8);
            }
        }finally{c.disconnect();}
    }
    public class Bridge {
        @JavascriptInterface public boolean hasKey(){return !prefs.getString("api_key","").isEmpty();}
        @JavascriptInterface public void configure(){runOnUiThread(()->{
            EditText input=new EditText(MainActivity.this);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
            input.setHint("Chiave API personale");
            new AlertDialog.Builder(MainActivity.this).setTitle("Alpha Vantage - piano gratuito")
                .setMessage("Inserisci una chiave gratuita personale dopo aver letto le condizioni d'uso. Non attivare piani a pagamento. La chiave resta nello spazio privato dell'app (non cifrata), non viene caricata su GitHub.")
                .setView(input).setNegativeButton("Annulla",null).setNeutralButton("Rimuovi",(d,w)->{prefs.edit().remove("api_key").apply();eval("window.marketKeyChanged()");})
                .setPositiveButton("Salva",(d,w)->{String key=input.getText().toString().trim();if(!key.matches("[A-Za-z0-9]{8,128}")){Toast.makeText(MainActivity.this,"Chiave non valida",Toast.LENGTH_LONG).show();return;}prefs.edit().putString("api_key",key).apply();eval("window.marketKeyChanged()");}).show();
        });}
        @JavascriptInterface public void closeApp(){runOnUiThread(()->finish());}
        @JavascriptInterface public void openExternal(String url){runOnUiThread(()->{try{Uri u=Uri.parse(url);if(!"https".equals(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||HOST.equals(u.getHost()))return;startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(MainActivity.this,"Collegamento non disponibile",Toast.LENGTH_SHORT).show();}});}
        @JavascriptInterface public void request(String id,String type,String name){
            if(!id.matches("[0-9]{1,12}"))return;
            if(!(type.equals("rss")&&FEEDS.containsKey(name))&&!(type.equals("price")&&SYMBOLS.contains(name))){done(id,false,"Richiesta non consentita");return;}
            worker.execute(()->{try{
                String url;boolean api=type.equals("price");
                if(api){String key=prefs.getString("api_key","");if(key.isEmpty()){done(id,false,"Chiave assente");return;}
                    String today=LocalDate.now(ZoneOffset.UTC).toString();String prefix="quota_";String stamp=prefs.getString(prefix+"date","");int used=stamp.equals(today)?prefs.getInt(prefix+"used",0):0;
                    if(used>=21||today.equals(prefs.getString("attempt_"+name,""))){done(id,false,"Limite locale giornaliero");return;}
                    // Conta anche i tentativi falliti, evitando cicli di retry e costi.
                    if(!prefs.edit().putString(prefix+"date",today).putInt(prefix+"used",used+1).putString("attempt_"+name,today).commit()){done(id,false,"Memoria non disponibile");return;}
                    String params=name.equals("BTC")?"function=DIGITAL_CURRENCY_DAILY&symbol=BTC&market=USD":"function=TIME_SERIES_DAILY&outputsize=compact&symbol="+name;
                    url="https://www.alphavantage.co/query?"+params+"&apikey="+URLEncoder.encode(key,"UTF-8");
                }else{url=FEEDS.get(name);}
                String result=fetch(url,api);done(id,true,result);
            }catch(Exception e){Log.w("MarketBriefing",type+"/"+name+": "+e.getClass().getSimpleName());done(id,false,e instanceof IllegalStateException?e.getMessage():"Connessione non disponibile");}});
        }
    }
}

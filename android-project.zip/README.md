# Market Briefing Android - versione 0.3.0 locale

Versione di prova personale, senza sito, backend, Claude o abbonamento. Android 11+ con Android System WebView aggiornato; interfaccia HTML/JS integrata in una Activity Android. Internet serve per scaricare nuove notizie e prezzi. Non contiene dati dimostrativi spacciati per reali.

## Compilazione gratuita dal browser
1. Accedi a https://github.com/new e crea un repository `market-briefing-android` con README, ramo `main`. Pubblico se accetti di rendere visibile il solo codice: i runner standard GitHub sono gratuiti. Privato se hai minuti gratuiti disponibili e un budget a zero; non aggiungere metodi di pagamento per questa prova.
2. Nel repository, Code > Add file > Upload files: carica il file `android-project.zip` senza estrarlo, nella radice. Commit changes.
3. Code > Add file > Create new file. Nome esatto `.github/workflows/build.yml`. Apri il `build.yml` fornito a parte con Blocco note, copia tutto nel nuovo file e conferma Commit changes. Il push su main avvia la compilazione. Se non parte, Actions > Compila APK Android > Run workflow.
4. Actions > Compila APK Android > esecuzione verde > Artifacts > Market-Briefing-APK. Scarica lo ZIP del risultato ed estrailo: contiene `Market-Briefing.apk` firmato con chiave debug. Copia il file APK sul tuo dispositivo, aprilo dal file manager e autorizza l'installazione da quella sorgente solo se riconosci questo APK. Non disabilitare Play Protect. Puoi disattivare l'autorizzazione dopo l'installazione.

Il certificato debug di una macchina CI nuova puo cambiare: questa e' una build di prova per uso personale, non release stabile. Per aggiornamenti futuri senza perdita di dati serve una chiave di firma privata persistente. In alternativa puo essere necessaria la disinstallazione della versione precedente, che cancella watchlist e dati locali.

## Primo utilizzo
- Apri l'app; le fonti RSS istituzionali vengono consultate direttamente. I titoli sono in inglese; non ci sono sintesi inventate o traduzioni automatiche. Il punteggio locale considera semplici parole chiave e lascia N/D i titoli non classificabili. Non rappresenta l'impatto economico effettivo sul settore.
- Per i prezzi, richiedi una chiave gratuita personale da https://www.alphavantage.co/support/#api-key dopo aver letto i termini https://www.alphavantage.co/terms_of_service/. Non scegliere Premium. Tocca l'ingranaggio e inserisci la chiave soltanto nell'app, non su GitHub. Nessuna chiave nel codice. La chiave e' in preferenze private Android non cifrate, backup disabilitato.
- Alpha Vantage dichiara 25 chiamate/giorno gratuite; l'app ne tenta al massimo 21 al giorno UTC, una per strumento, contando gli errori. Altre app che condividono la chiave possono consumare quota. Le fonti possono cambiare o limitare un simbolo: N/D in caso di assenza di dati. I dati sono solo personali, non redistribuire. La chiave puo essere rimossa dalle impostazioni; le copie gia salvate restano localmente.
- 5 indicatori di settore: GLD (fondo aurifero), SMH (ETF chip), BTC/USD, USO (fondo legato ai future WTI), AIQ (ETF tecnologia). GLD e USO non sono spot/future; esposizione e rendimenti possono differire. 16 azioni quotate negli USA, incluse societa europee tramite quotazioni/ADR USA; niente listini italiani diretti. Quotazioni di fine seduta, non intraday; variazione tra due ultime chiusure, non esattamente 24h. Storico non rettificato per split/dividendi; possibili anomalie sono segnalate, non tutte rilevabili. Screener non validato, nessun ordine automatico.
- I feed RSS si aggiornano all'apertura/ripresa e ogni ora mentre l'app e' in primo piano, non quando l'app e' chiusa. Prezzi una volta per giorno UTC, con esclusione prudente della seduta corrente. Eventuali errori sono visibili; conservazione locale delle notizie fino a 90 giorni, fino a 100 osservazioni di prezzo per simbolo (soggette ai termini del fornitore), watchlist sul telefono tramite localStorage. Nessuna sincronizzazione cloud. Nessuna consulenza finanziaria.

## Test e sviluppo
- `node --test tests/market.test.js`: 16 test di calcolo su dati sintetici.
- `node --check app/src/main/assets/local.js` e `node --check app/src/main/assets/app.js`: sintassi.
- Build locale opzionale con Android SDK 35, build-tools 34.0.0, Gradle 8.9, Java 17: `gradle :app:assembleDebug`.
- La logica e la UI sono state provate in Chromium con bridge simulato e contenuto iniettato. Non si e' compilato l'APK qui perche l'SDK non e' disponibile; il bridge nativo e le richieste live devono essere collaudati su Android. Le fonti RSS sono solo URL istituzionali, non scraping e nessun aggiramento dei blocchi; feed con redirect o errori vengono segnalati.
- Backtest e paper trading non sono inclusi. Verranno sviluppati dopo il collaudo della versione gratuita.
